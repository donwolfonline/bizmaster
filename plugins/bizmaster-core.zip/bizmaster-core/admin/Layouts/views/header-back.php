<button type="button" class="wowaddons-template-library-back">
	<i class="dashicons dashicons-arrow-left-alt2"></i>
	<?php esc_html_e( 'Back to Library', 'wowaddons' ); ?>
</button> 