<?php
/**
 * Template Library Header Template
 */
?>
<label>
	<input type="radio" value="{{ slug }}" name="wowaddons-modal-tab">
	<span>{{ title }}</span>
</label>