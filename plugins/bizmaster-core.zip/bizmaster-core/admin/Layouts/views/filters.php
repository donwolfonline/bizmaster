<?php
/**
 * Template Library Header Template
 */
?>
<div id="wowaddons-template-library-filters-container"></div>