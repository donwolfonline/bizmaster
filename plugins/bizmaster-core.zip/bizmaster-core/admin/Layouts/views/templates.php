<?php
/**
 * Templates list view
 */
?>
<div id="wowaddons-template-library-templates-container"></div>