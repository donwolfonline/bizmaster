<?php
/**
 * templates loader view
 */

?>
<div class="wowaddons-filters-list"></div>
<div class="wowaddons-templates-wrap">
	<div class="wowaddons-keywords-list"></div>
	<div class="wowaddons-templates-list"></div>
</div>