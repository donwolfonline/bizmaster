<?php include('live-button.php'); ?>

<a  href="#" target="_blank" >
	<button class="elementor-template-library-template-action wowaddons-preview-button-go-pro wowaddons-template-library-template-insert wowaddons-preview-button-go-pro elementor-button elementor-button-success" >
		<i class="eicon-heart"></i><span class="elementor-button-title"><?php
			esc_html_e( 'Go Pro', 'wowaddons' );
		?></span>
	</button>
</a>